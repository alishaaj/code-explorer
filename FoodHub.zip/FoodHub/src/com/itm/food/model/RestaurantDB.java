package com.itm.food.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.itm.food.dao.AbstractDomain;
import com.itm.food.dao.Restaurant;
import com.itm.food.model.db.MySQLQuery;
import com.mysql.jdbc.Statement;

public class RestaurantDB extends AbstractDB implements IDBAccess {

	private static final Logger log = Logger.getLogger(RestaurantDB.class);

	@Override
	public <T extends AbstractDomain> int add(T object) throws Exception {
		Restaurant restaurant = (Restaurant) object;
		try {
			PreparedStatement statement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_INSERT, Statement.RETURN_GENERATED_KEYS);
			statement.setString(1, restaurant.getRestaurantName());
			statement.setString(2, restaurant.getRestaurantDescription());
			statement.setString(3, restaurant.getAddress1());
			statement.setString(4, restaurant.getAddress2());
			statement.setString(5, restaurant.getCity());
			statement.setInt(6, restaurant.getZipcode());
			statement.setString(7, restaurant.getEmail());
			statement.setString(8, restaurant.getPhone());

			statement.executeUpdate();
			ResultSet rs = statement.getGeneratedKeys();
			while (rs.next()) {
				restaurant.setRestaurantId(rs.getInt(1));
			}
			log.debug("Data inserted for restaurant ");
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		}
		return restaurant.getRestaurantId();
	}

	@Override
	public <T extends AbstractDomain> void update(T object) throws Exception {
		Restaurant restaurant = (Restaurant) object;
		try {
			PreparedStatement statement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_UPDATE);
			statement.setString(1, restaurant.getRestaurantName());
			statement.setString(2, restaurant.getRestaurantDescription());
			statement.setString(3, restaurant.getAddress1());
			statement.setString(4, restaurant.getAddress2());
			statement.setString(5, restaurant.getCity());
			statement.setInt(6, restaurant.getZipcode());
			statement.setString(7, restaurant.getEmail());
			statement.setString(8, restaurant.getPhone());
			statement.setInt(9, restaurant.getRestaurantId());
			statement.executeUpdate();
			log.debug("Data updated for restaurant " + restaurant.getRestaurantId());
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public <T extends AbstractDomain> T find(int id) throws Exception {
		log.debug("Getting Restaurant for the RestaurantId: " + id);
		ResultSet rsRestaurant;
		Restaurant restaurant = new Restaurant();
		try {
			PreparedStatement preparestatement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_RESTAURANT_SELECT);
			preparestatement.setInt(1, id);
			rsRestaurant = preparestatement.executeQuery();
			while (rsRestaurant.next()) {
				restaurant.setRestaurantId(rsRestaurant.getInt(1));
				restaurant.setRestaurantName(rsRestaurant.getString(2));
				restaurant.setRestaurantDescription(rsRestaurant.getString(3));
				restaurant.setAddress1(rsRestaurant.getString(4));
				restaurant.setAddress2(rsRestaurant.getString(5));
				restaurant.setCity(rsRestaurant.getString(6));
				restaurant.setZipcode(rsRestaurant.getInt(7));
				restaurant.setRating(rsRestaurant.getInt(8));
				restaurant.setPhone(rsRestaurant.getString(9));
				restaurant.setEmail(rsRestaurant.getString(10));
				restaurant.setLatitude(rsRestaurant.getDouble(11));
				restaurant.setLongitude(rsRestaurant.getDouble(12));
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return (T) restaurant;
	}

	@Override
	public <T extends AbstractDomain> void delete(T object) throws Exception {
		Restaurant restaurant = (Restaurant) object;
		try {
			PreparedStatement statement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_DELETE);
			statement.setInt(1, restaurant.getRestaurantId());
			statement.executeUpdate();
			log.debug("Data deleted for restaurant " + restaurant.getRestaurantId());
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		}

	}

	@Override
	public void delete(int id) throws Exception {
		try {
			PreparedStatement statement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_DELETE);
			statement.setInt(1, id);
			statement.executeUpdate();
			log.debug("Data deleted for restaurant " + id);
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		}
	}

	public ArrayList<Restaurant> searchByZip(List<Integer> zipcodes) throws SQLException {
		log.debug("Searching restaurant for zip: " + zipcodes);
		ArrayList<Restaurant> restaurantsList = new ArrayList<Restaurant>();

		// Retrieving columns
		// RESTAURANT_ID,RESTAURANT_NAME,ADDRESS1,ADDRESS2,CITY,RATING,PHONE,EMAIL
		// from
		// ofod.ofod_restaurant table
		try {
			int searchLimit = 20;
			StringBuilder parameterBuilder = new StringBuilder();
			parameterBuilder.append(" (");
			for (int i = 0; i < zipcodes.size(); i++) {
				parameterBuilder.append("?");
				if (zipcodes.size() > i + 1) {
					parameterBuilder.append(",");
				}
			}
			parameterBuilder.append(")");

			String sqlQuery = "SELECT R.RESTAURANT_ID,RESTAURANT_NAME,DESCRIPTION,ADDRESS1,ADDRESS2,CITY,ZIPCODE,AVG(UR.RATING) AS RATING,"
					+ "PHONE,EMAIL,LATITUDE,LONGITUDE FROM ofod_restaurant R "
					+ " LEFT JOIN  ofod_restaurant_rating RR ON R.RESTAURANT_ID = RR.RESTAURANT_ID "
					+ " LEFT JOIN ofod_user_rating UR ON UR.RATING_ID = RR.RATING_ID " + " WHERE ZIPCODE IN"
					+ parameterBuilder.toString() + "  GROUP BY R.RESTAURANT_ID " + " ORDER BY RATING DESC LIMIT ?";

			PreparedStatement preparedstatement = this.getDBConnection().prepareStatement(sqlQuery);

			for (int i = 1; i < zipcodes.size() + 1; i++) {
				preparedstatement.setInt(i, (int) zipcodes.get(i - 1));
			}

			preparedstatement.setInt(zipcodes.size() + 1, searchLimit);
			// preparedstatement.setString(1, StringUtils.join(zipcodes, ","));
			ResultSet restaurantsResultSet;
			restaurantsResultSet = preparedstatement.executeQuery();

			while (restaurantsResultSet.next()) {
				Restaurant newRestaurant = new Restaurant();

				// Fetching the restaurants column data and setting it to the
				// respective dao object
				newRestaurant.setRestaurantId(restaurantsResultSet.getInt(1));
				newRestaurant.setRestaurantName(restaurantsResultSet.getString(2));
				newRestaurant.setRestaurantDescription(restaurantsResultSet.getString(3));
				newRestaurant.setAddress1(restaurantsResultSet.getString(4));
				newRestaurant.setAddress2(restaurantsResultSet.getString(5));
				newRestaurant.setCity(restaurantsResultSet.getString(6));
				newRestaurant.setZipcode(restaurantsResultSet.getInt(7));
				newRestaurant.setRating(restaurantsResultSet.getInt(8));
				newRestaurant.setPhone(restaurantsResultSet.getString(9));
				newRestaurant.setEmail(restaurantsResultSet.getString(10));
				newRestaurant.setLatitude(restaurantsResultSet.getDouble(11));
				newRestaurant.setLongitude(restaurantsResultSet.getDouble(12));

				// add all restaurants to the RestaurantsList ArrayList
				restaurantsList.add(newRestaurant);
			}
			preparedstatement.close();
		} catch (Exception e) {
			log.error(e.getMessage());

		}
		return restaurantsList;

	}

	public List<Restaurant> getTop3Restaurants() {

		log.debug("Getting top 3 restaurants from RestaurantDB");
		List<Restaurant> top3RestaurantsList = new ArrayList<Restaurant>();
		// RESTAURANT_ID,RESTAURANT_NAME,DESCRIPTION,ADDRESS1,ADDRESS2,CITY,ZIPCODE,PHONE,EMAIL,
		// RATING
		try {
			PreparedStatement preparestatement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_FETCH_TOP_3_RESTAURANTS);
			ResultSet rsTopRestaurants;
			rsTopRestaurants = preparestatement.executeQuery();
			while (rsTopRestaurants.next()) {
				Restaurant restaurant = new Restaurant();
				restaurant.setRestaurantId(rsTopRestaurants.getInt(1));
				restaurant.setRestaurantName(rsTopRestaurants.getString(2));
				restaurant.setRestaurantDescription(rsTopRestaurants.getString(3));
				restaurant.setAddress1(rsTopRestaurants.getString(4));
				restaurant.setAddress2(rsTopRestaurants.getString(5));
				restaurant.setCity(rsTopRestaurants.getString(6));
				restaurant.setZipcode(rsTopRestaurants.getInt(7));
				restaurant.setPhone(rsTopRestaurants.getString(8));
				restaurant.setEmail(rsTopRestaurants.getString(9));
				restaurant.setRating(rsTopRestaurants.getDouble(10));

				top3RestaurantsList.add(restaurant);

			}
		} catch (ClassNotFoundException e) {
			log.error(e.getMessage());
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return top3RestaurantsList;
	}

	public int getRestaurantCount() throws Exception {
		ResultSet rs = null;
		int count = 0;
		try {
			PreparedStatement statement = this.getDBConnection()
					.prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_COUNT);
			rs = statement.executeQuery();
			log.debug(" count retrieved from restaurant");
			if (rs.next())
				count = rs.getInt(1);
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		} finally {
			rs.close();
		}
		return count;
	}

	public ResultSet getAllRestaurants() throws Exception {
		ResultSet rs = null;
		try {
			PreparedStatement statement = this.getDBConnection().prepareStatement(MySQLQuery.SQL_ADMIN_RESTAURANT_ALL);
			rs = statement.executeQuery();
			log.debug("Data selected from restaurants table");
		} catch (SQLException s) {
			log.error(s.getMessage(), s);
			throw s;
		}
		return rs;
	}

}
