package com.itm.food.dao;

public abstract class AbstractDomain {
	
}
