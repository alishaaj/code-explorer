package com.itm.food.dao.operation;

import java.util.List;

import org.apache.log4j.Logger;

import com.itm.food.dao.Payment;
import com.itm.food.model.PaymentDB;

public class PaymentOperations {

	private static final Logger log = Logger.getLogger(PaymentOperations.class);

	PaymentDB paymentDB = new PaymentDB();

	public int addPaymentInfo(Payment newCard) {
		log.info("payment operations started");
		int cardId = 0;
		try {
			cardId = paymentDB.add(newCard);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		log.debug("cardId returned to paymentOperations :" + cardId);
		return cardId;

	}

	public List<Payment> getCards(int i) throws Exception {
		return paymentDB.getAllCardsFromDB(i);

	}

}
